"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Plus, Search, Shirt, ArrowLeft, Filter } from "lucide-react"

const SAMPLE_ITEMS = [
  {
    id: 1,
    name: "White Oxford Shirt",
    category: "Tops",
    season: "All",
    color: "White",
    image: "/white-oxford-shirt.png",
  },
  {
    id: 2,
    name: "Navy Blazer",
    category: "Outerwear",
    season: "Fall",
    color: "Navy",
    image: "/navy-blazer.png",
  },
  {
    id: 3,
    name: "Black Trousers",
    category: "Bottoms",
    season: "All",
    color: "Black",
    image: "/black-trousers.png",
  },
  {
    id: 4,
    name: "Grey Sweater",
    category: "Tops",
    season: "Winter",
    color: "Grey",
    image: "/grey-sweater.jpg",
  },
  {
    id: 5,
    name: "Denim Jacket",
    category: "Outerwear",
    season: "Spring",
    color: "Blue",
    image: "/classic-denim-jacket.png",
  },
  {
    id: 6,
    name: "White Sneakers",
    category: "Shoes",
    season: "All",
    color: "White",
    image: "/white-sneakers.png",
  },
  {
    id: 7,
    name: "Beige Chinos",
    category: "Bottoms",
    season: "Summer",
    color: "Beige",
    image: "/beige-chinos.png",
  },
  {
    id: 8,
    name: "Striped T-Shirt",
    category: "Tops",
    season: "Summer",
    color: "Multi",
    image: "/striped-t-shirt.png",
  },
]

const CATEGORIES = ["All", "Tops", "Bottoms", "Outerwear", "Shoes", "Accessories"]

export default function WardrobePage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("All")

  const filteredItems = SAMPLE_ITEMS.filter((item) => {
    const matchesSearch = item.name.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesCategory = selectedCategory === "All" || item.category === selectedCategory
    return matchesSearch && matchesCategory
  })

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Button variant="ghost" size="icon" asChild>
                <Link href="/">
                  <ArrowLeft className="w-5 h-5" />
                </Link>
              </Button>
              <div className="flex items-center gap-2">
                <Shirt className="w-6 h-6 text-primary" />
                <h1 className="text-2xl font-bold">My Wardrobe</h1>
              </div>
            </div>
            <Button size="lg">
              <Plus className="w-5 h-5 mr-2" />
              Add Item
            </Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {/* Filters */}
        <div className="mb-8 space-y-4">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              <Input
                placeholder="Search your wardrobe..."
                className="pl-10"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
              <SelectTrigger className="w-full md:w-48">
                <Filter className="w-4 h-4 mr-2" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {CATEGORIES.map((category) => (
                  <SelectItem key={category} value={category}>
                    {category}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-center justify-between">
            <p className="text-sm text-muted-foreground">
              Showing {filteredItems.length} {filteredItems.length === 1 ? "item" : "items"}
            </p>
            <div className="flex gap-2">
              {CATEGORIES.slice(1).map((category) => (
                <Badge
                  key={category}
                  variant={selectedCategory === category ? "default" : "outline"}
                  className="cursor-pointer"
                  onClick={() => setSelectedCategory(category)}
                >
                  {category}
                </Badge>
              ))}
            </div>
          </div>
        </div>

        {/* Items Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {filteredItems.map((item) => (
            <Card key={item.id} className="group hover:shadow-lg transition-all cursor-pointer">
              <CardContent className="p-0">
                <div className="aspect-square overflow-hidden rounded-t-lg bg-muted">
                  <img
                    src={item.image || "/placeholder.svg"}
                    alt={item.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                  />
                </div>
                <div className="p-4">
                  <h3 className="font-semibold mb-2 text-sm">{item.name}</h3>
                  <div className="flex items-center gap-2 flex-wrap">
                    <Badge variant="secondary" className="text-xs">
                      {item.category}
                    </Badge>
                    <Badge variant="outline" className="text-xs">
                      {item.season}
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Empty State */}
        {filteredItems.length === 0 && (
          <div className="text-center py-16">
            <Shirt className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-semibold mb-2">No items found</h3>
            <p className="text-muted-foreground mb-6">Try adjusting your search or filters</p>
            <Button
              onClick={() => {
                setSearchQuery("")
                setSelectedCategory("All")
              }}
            >
              Clear Filters
            </Button>
          </div>
        )}
      </main>
    </div>
  )
}
