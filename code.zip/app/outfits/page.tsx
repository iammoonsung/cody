"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Plus, ArrowLeft, Star, Sparkles } from "lucide-react"

const FORMALITY_COLORS = [
  "bg-[oklch(var(--formality-1))]",
  "bg-[oklch(var(--formality-2))]",
  "bg-[oklch(var(--formality-3))]",
  "bg-[oklch(var(--formality-4))]",
  "bg-[oklch(var(--formality-5))]",
]

const SAMPLE_OUTFITS = [
  {
    id: 1,
    name: "Office Casual",
    items: ["White Oxford Shirt", "Navy Blazer", "Black Trousers"],
    formality: 4,
    rating: 5,
    wornCount: 12,
    lastWorn: "2025-01-08",
  },
  {
    id: 2,
    name: "Weekend Brunch",
    items: ["Striped T-Shirt", "Beige Chinos", "White Sneakers"],
    formality: 2,
    rating: 4,
    wornCount: 8,
    lastWorn: "2025-01-06",
  },
  {
    id: 3,
    name: "Smart Casual",
    items: ["Grey Sweater", "Denim Jacket", "Black Trousers"],
    formality: 3,
    rating: 5,
    wornCount: 15,
    lastWorn: "2025-01-09",
  },
  {
    id: 4,
    name: "Summer Day",
    items: ["Striped T-Shirt", "Beige Chinos", "White Sneakers"],
    formality: 1,
    rating: 3,
    wornCount: 5,
    lastWorn: "2024-12-28",
  },
]

export default function OutfitsPage() {
  const [selectedFormality, setSelectedFormality] = useState<number | null>(null)

  const filteredOutfits = selectedFormality
    ? SAMPLE_OUTFITS.filter((outfit) => outfit.formality === selectedFormality)
    : SAMPLE_OUTFITS

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Button variant="ghost" size="icon" asChild>
                <Link href="/">
                  <ArrowLeft className="w-5 h-5" />
                </Link>
              </Button>
              <div className="flex items-center gap-2">
                <Sparkles className="w-6 h-6 text-accent" />
                <h1 className="text-2xl font-bold">Saved Outfits</h1>
              </div>
            </div>
            <Button size="lg">
              <Plus className="w-5 h-5 mr-2" />
              Create Outfit
            </Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {/* Formality Filter */}
        <div className="mb-8">
          <h3 className="text-sm font-semibold mb-4">Filter by Formality Level</h3>
          <div className="flex gap-2 flex-wrap">
            <Button
              variant={selectedFormality === null ? "default" : "outline"}
              onClick={() => setSelectedFormality(null)}
              size="sm"
            >
              All
            </Button>
            {[1, 2, 3, 4, 5].map((level) => (
              <Button
                key={level}
                variant={selectedFormality === level ? "default" : "outline"}
                onClick={() => setSelectedFormality(level)}
                size="sm"
                className="flex items-center gap-2"
              >
                <div className={`w-3 h-3 rounded-full ${FORMALITY_COLORS[level - 1]}`} />
                Level {level}
              </Button>
            ))}
          </div>
          <p className="text-xs text-muted-foreground mt-2">1 = Very Casual • 5 = Very Formal</p>
        </div>

        {/* Outfits Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredOutfits.map((outfit) => (
            <Card key={outfit.id} className="hover:shadow-lg transition-shadow cursor-pointer">
              <CardContent className="p-6">
                {/* Outfit Preview */}
                <div className="aspect-square bg-muted rounded-lg mb-4 flex items-center justify-center">
                  <img
                    src={`/.jpg?height=300&width=300&query=${outfit.name}`}
                    alt={outfit.name}
                    className="w-full h-full object-cover rounded-lg"
                  />
                </div>

                {/* Outfit Info */}
                <div className="space-y-3">
                  <div className="flex items-start justify-between">
                    <h3 className="font-semibold text-lg">{outfit.name}</h3>
                    <div className="flex items-center gap-1">
                      {Array.from({ length: 5 }).map((_, i) => (
                        <Star
                          key={i}
                          className={`w-4 h-4 ${
                            i < outfit.rating ? "fill-primary text-primary" : "text-muted-foreground/30"
                          }`}
                        />
                      ))}
                    </div>
                  </div>

                  {/* Formality Badge */}
                  <div className="flex items-center gap-2">
                    <div className={`w-4 h-4 rounded-full ${FORMALITY_COLORS[outfit.formality - 1]}`} />
                    <span className="text-sm text-muted-foreground">Formality Level {outfit.formality}</span>
                  </div>

                  {/* Items List */}
                  <div className="flex flex-wrap gap-2">
                    {outfit.items.map((item, index) => (
                      <Badge key={index} variant="secondary" className="text-xs">
                        {item}
                      </Badge>
                    ))}
                  </div>

                  {/* Stats */}
                  <div className="flex items-center justify-between text-sm text-muted-foreground pt-2 border-t border-border">
                    <span>Worn {outfit.wornCount}x</span>
                    <span>Last: {new Date(outfit.lastWorn).toLocaleDateString()}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Empty State */}
        {filteredOutfits.length === 0 && (
          <div className="text-center py-16">
            <Sparkles className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-semibold mb-2">No outfits found</h3>
            <p className="text-muted-foreground mb-6">Try adjusting your filters or create a new outfit</p>
            <Button onClick={() => setSelectedFormality(null)}>Clear Filters</Button>
          </div>
        )}
      </main>
    </div>
  )
}
