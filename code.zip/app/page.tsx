import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Sparkles, Briefcase, Coffee, Calendar, Shirt } from "lucide-react"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Shirt className="w-8 h-8 text-primary" />
              <h1 className="text-2xl font-bold text-balance">오늘뭐입지?</h1>
            </div>
            <nav className="flex items-center gap-2">
              <Button variant="ghost" asChild>
                <Link href="/wardrobe">Wardrobe</Link>
              </Button>
              <Button variant="ghost" asChild>
                <Link href="/outfits">Outfits</Link>
              </Button>
              <Button variant="ghost" asChild>
                <Link href="/calendar">Calendar</Link>
              </Button>
            </nav>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {/* Hero Section */}
        <div className="text-center mb-12">
          <h2 className="text-4xl md:text-5xl font-bold mb-4 text-balance">What should I wear today?</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto text-pretty">
            Get instant outfit recommendations based on your wardrobe, weather, and occasion
          </p>
        </div>

        {/* Quick Actions */}
        <div className="grid md:grid-cols-2 gap-6 max-w-4xl mx-auto mb-12">
          <Card className="border-2 border-primary hover:shadow-lg transition-shadow cursor-pointer">
            <CardContent className="p-8 text-center">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Briefcase className="w-8 h-8 text-primary" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Work Outfit</h3>
              <p className="text-muted-foreground mb-4">Professional looks for the office</p>
              <Button className="w-full" size="lg">
                <Sparkles className="w-4 h-4 mr-2" />
                Get Recommendation
              </Button>
            </CardContent>
          </Card>

          <Card className="border-2 border-accent hover:shadow-lg transition-shadow cursor-pointer">
            <CardContent className="p-8 text-center">
              <div className="w-16 h-16 bg-accent/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Coffee className="w-8 h-8 text-accent" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Casual Outing</h3>
              <p className="text-muted-foreground mb-4">Relaxed styles for weekends</p>
              <Button className="w-full" variant="secondary" size="lg">
                <Sparkles className="w-4 h-4 mr-2" />
                Get Recommendation
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto">
          <Link href="/wardrobe" className="group">
            <Card className="h-full hover:shadow-md transition-shadow">
              <CardContent className="p-6">
                <Shirt className="w-10 h-10 text-primary mb-4 group-hover:scale-110 transition-transform" />
                <h3 className="text-lg font-semibold mb-2">My Wardrobe</h3>
                <p className="text-sm text-muted-foreground">Manage your clothing items with photos and categories</p>
              </CardContent>
            </Card>
          </Link>

          <Link href="/outfits" className="group">
            <Card className="h-full hover:shadow-md transition-shadow">
              <CardContent className="p-6">
                <Sparkles className="w-10 h-10 text-accent mb-4 group-hover:scale-110 transition-transform" />
                <h3 className="text-lg font-semibold mb-2">Saved Outfits</h3>
                <p className="text-sm text-muted-foreground">Create and rate outfit combinations for quick access</p>
              </CardContent>
            </Card>
          </Link>

          <Link href="/calendar" className="group">
            <Card className="h-full hover:shadow-md transition-shadow">
              <CardContent className="p-6">
                <Calendar className="w-10 h-10 text-[oklch(var(--formality-3))] mb-4 group-hover:scale-110 transition-transform" />
                <h3 className="text-lg font-semibold mb-2">History</h3>
                <p className="text-sm text-muted-foreground">Track what you wore and when with calendar view</p>
              </CardContent>
            </Card>
          </Link>
        </div>

        {/* Stats Preview */}
        <div className="mt-12 max-w-4xl mx-auto">
          <Card>
            <CardContent className="p-8">
              <div className="grid grid-cols-3 gap-6 text-center">
                <div>
                  <div className="text-3xl font-bold text-primary mb-1">24</div>
                  <div className="text-sm text-muted-foreground">Wardrobe Items</div>
                </div>
                <div>
                  <div className="text-3xl font-bold text-accent mb-1">12</div>
                  <div className="text-sm text-muted-foreground">Saved Outfits</div>
                </div>
                <div>
                  <div className="text-3xl font-bold text-[oklch(var(--formality-3))] mb-1">87</div>
                  <div className="text-sm text-muted-foreground">Days Tracked</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
