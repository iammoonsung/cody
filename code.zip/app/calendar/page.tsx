"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { ArrowLeft, CalendarIcon, ChevronLeft, ChevronRight } from "lucide-react"

const FORMALITY_COLORS = [
  "bg-[oklch(var(--formality-1))]",
  "bg-[oklch(var(--formality-2))]",
  "bg-[oklch(var(--formality-3))]",
  "bg-[oklch(var(--formality-4))]",
  "bg-[oklch(var(--formality-5))]",
]

const SAMPLE_CALENDAR_DATA = {
  "2025-01-01": { outfit: "Weekend Brunch", formality: 2 },
  "2025-01-02": { outfit: "Smart Casual", formality: 3 },
  "2025-01-03": { outfit: "Office Casual", formality: 4 },
  "2025-01-06": { outfit: "Weekend Brunch", formality: 2 },
  "2025-01-07": { outfit: "Office Casual", formality: 4 },
  "2025-01-08": { outfit: "Office Casual", formality: 4 },
  "2025-01-09": { outfit: "Smart Casual", formality: 3 },
  "2025-01-10": { outfit: "Office Casual", formality: 4 },
}

export default function CalendarPage() {
  const [currentDate, setCurrentDate] = useState(new Date(2025, 0, 1))

  const getDaysInMonth = (date: Date) => {
    const year = date.getFullYear()
    const month = date.getMonth()
    const firstDay = new Date(year, month, 1)
    const lastDay = new Date(year, month + 1, 0)
    const daysInMonth = lastDay.getDate()
    const startingDayOfWeek = firstDay.getDay()

    return { daysInMonth, startingDayOfWeek }
  }

  const { daysInMonth, startingDayOfWeek } = getDaysInMonth(currentDate)

  const previousMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1))
  }

  const nextMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1))
  }

  const formatDate = (day: number) => {
    const year = currentDate.getFullYear()
    const month = String(currentDate.getMonth() + 1).padStart(2, "0")
    const dayStr = String(day).padStart(2, "0")
    return `${year}-${month}-${dayStr}`
  }

  const monthName = currentDate.toLocaleDateString("en-US", { month: "long", year: "numeric" })

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon" asChild>
              <Link href="/">
                <ArrowLeft className="w-5 h-5" />
              </Link>
            </Button>
            <div className="flex items-center gap-2">
              <CalendarIcon className="w-6 h-6 text-[oklch(var(--formality-3))]" />
              <h1 className="text-2xl font-bold">Outfit Calendar</h1>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8 max-w-6xl">
        {/* Calendar Controls */}
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-2xl font-bold">{monthName}</h2>
          <div className="flex gap-2">
            <Button variant="outline" size="icon" onClick={previousMonth}>
              <ChevronLeft className="w-5 h-5" />
            </Button>
            <Button variant="outline" size="icon" onClick={nextMonth}>
              <ChevronRight className="w-5 h-5" />
            </Button>
          </div>
        </div>

        {/* Calendar Grid */}
        <Card>
          <CardContent className="p-4">
            {/* Weekday Headers */}
            <div className="grid grid-cols-7 gap-2 mb-2">
              {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((day) => (
                <div key={day} className="text-center font-semibold text-sm text-muted-foreground py-2">
                  {day}
                </div>
              ))}
            </div>

            {/* Calendar Days */}
            <div className="grid grid-cols-7 gap-2">
              {/* Empty cells for days before month starts */}
              {Array.from({ length: startingDayOfWeek }).map((_, index) => (
                <div key={`empty-${index}`} className="aspect-square" />
              ))}

              {/* Actual days */}
              {Array.from({ length: daysInMonth }).map((_, index) => {
                const day = index + 1
                const dateStr = formatDate(day)
                const outfitData = SAMPLE_CALENDAR_DATA[dateStr as keyof typeof SAMPLE_CALENDAR_DATA]
                const isToday = dateStr === "2025-01-10"

                return (
                  <div
                    key={day}
                    className={`aspect-square border rounded-lg p-2 cursor-pointer hover:border-primary transition-colors ${
                      isToday ? "border-primary border-2" : "border-border"
                    }`}
                  >
                    <div className="text-sm font-semibold mb-1">{day}</div>
                    {outfitData && (
                      <div className="space-y-1">
                        <div className={`w-full h-2 rounded-full ${FORMALITY_COLORS[outfitData.formality - 1]}`} />
                        <div className="text-xs text-muted-foreground truncate">{outfitData.outfit}</div>
                      </div>
                    )}
                  </div>
                )
              })}
            </div>
          </CardContent>
        </Card>

        {/* Legend */}
        <div className="mt-8">
          <h3 className="text-sm font-semibold mb-4">Formality Levels</h3>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            {[
              { level: 1, label: "Very Casual" },
              { level: 2, label: "Casual" },
              { level: 3, label: "Smart Casual" },
              { level: 4, label: "Business" },
              { level: 5, label: "Formal" },
            ].map(({ level, label }) => (
              <div key={level} className="flex items-center gap-2">
                <div className={`w-4 h-4 rounded-full ${FORMALITY_COLORS[level - 1]}`} />
                <span className="text-sm text-muted-foreground">{label}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Stats Card */}
        <Card className="mt-8">
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold mb-4">This Month's Stats</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div>
                <div className="text-2xl font-bold text-primary">8</div>
                <div className="text-sm text-muted-foreground">Days Tracked</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-accent">4</div>
                <div className="text-sm text-muted-foreground">Unique Outfits</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-[oklch(var(--formality-4))]">3.2</div>
                <div className="text-sm text-muted-foreground">Avg Formality</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-[oklch(var(--formality-2))]">4</div>
                <div className="text-sm text-muted-foreground">Most Worn</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
