import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Sparkles, Briefcase, Coffee, Calendar, Shirt, ChevronRight } from "lucide-react"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border/50 bg-background/80 backdrop-blur-md sticky top-0 z-10">
        <div className="container mx-auto px-6 py-6">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center gap-3 group">
              <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center group-hover:bg-primary/20 transition-colors">
                <Shirt className="w-4 h-4 text-primary" />
              </div>
              <h1 className="text-xl font-serif tracking-tight text-balance">오늘뭐입지?</h1>
            </Link>
            <nav className="flex items-center gap-1">
              <Button variant="ghost" size="sm" className="text-sm" asChild>
                <Link href="/wardrobe">Wardrobe</Link>
              </Button>
              <Button variant="ghost" size="sm" className="text-sm" asChild>
                <Link href="/outfits">Outfits</Link>
              </Button>
              <Button variant="ghost" size="sm" className="text-sm" asChild>
                <Link href="/calendar">Calendar</Link>
              </Button>
            </nav>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-6">
        <div className="text-center py-20 max-w-3xl mx-auto">
          <h2 className="text-5xl md:text-6xl font-serif font-light mb-6 text-balance tracking-tight">
            What should I wear today?
          </h2>
          <p className="text-lg text-muted-foreground leading-relaxed text-pretty">
            Curated outfit recommendations tailored to your wardrobe, weather, and occasion
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto mb-24">
          <Card className="border border-border/50 hover:border-primary/30 hover:shadow-sm transition-all duration-300 group cursor-pointer">
            <CardContent className="p-10">
              <div className="w-12 h-12 rounded-full bg-primary/5 flex items-center justify-center mb-6 group-hover:bg-primary/10 transition-colors">
                <Briefcase className="w-6 h-6 text-primary" />
              </div>
              <h3 className="text-2xl font-serif font-light mb-3 text-balance">Work Outfit</h3>
              <p className="text-muted-foreground leading-relaxed mb-6">Professional looks for the office</p>
              <Button variant="ghost" className="px-0 group-hover:gap-2 transition-all">
                Get Recommendation
                <ChevronRight className="w-4 h-4 ml-1 group-hover:translate-x-1 transition-transform" />
              </Button>
            </CardContent>
          </Card>

          <Card className="border border-border/50 hover:border-accent/30 hover:shadow-sm transition-all duration-300 group cursor-pointer">
            <CardContent className="p-10">
              <div className="w-12 h-12 rounded-full bg-accent/5 flex items-center justify-center mb-6 group-hover:bg-accent/10 transition-colors">
                <Coffee className="w-6 h-6 text-accent" />
              </div>
              <h3 className="text-2xl font-serif font-light mb-3 text-balance">Casual Outing</h3>
              <p className="text-muted-foreground leading-relaxed mb-6">Relaxed styles for weekends</p>
              <Button variant="ghost" className="px-0 group-hover:gap-2 transition-all">
                Get Recommendation
                <ChevronRight className="w-4 h-4 ml-1 group-hover:translate-x-1 transition-transform" />
              </Button>
            </CardContent>
          </Card>
        </div>

        <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto mb-24">
          <Link href="/wardrobe" className="group">
            <Card className="h-full border border-border/50 hover:border-border transition-all duration-300">
              <CardContent className="p-8">
                <Shirt className="w-8 h-8 text-foreground/60 mb-6 group-hover:text-foreground transition-colors" />
                <h3 className="text-lg font-light mb-2">My Wardrobe</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">Manage your clothing collection</p>
              </CardContent>
            </Card>
          </Link>

          <Link href="/outfits" className="group">
            <Card className="h-full border border-border/50 hover:border-border transition-all duration-300">
              <CardContent className="p-8">
                <Sparkles className="w-8 h-8 text-foreground/60 mb-6 group-hover:text-foreground transition-colors" />
                <h3 className="text-lg font-light mb-2">Saved Outfits</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">Curated outfit combinations</p>
              </CardContent>
            </Card>
          </Link>

          <Link href="/calendar" className="group">
            <Card className="h-full border border-border/50 hover:border-border transition-all duration-300">
              <CardContent className="p-8">
                <Calendar className="w-8 h-8 text-foreground/60 mb-6 group-hover:text-foreground transition-colors" />
                <h3 className="text-lg font-light mb-2">History</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">Track your daily outfits</p>
              </CardContent>
            </Card>
          </Link>
        </div>

        <div className="max-w-4xl mx-auto pb-24">
          <Card className="border border-border/50">
            <CardContent className="p-12">
              <div className="grid grid-cols-3 gap-12 text-center">
                <div>
                  <div className="text-4xl font-serif font-light text-foreground mb-2">24</div>
                  <div className="text-sm text-muted-foreground uppercase tracking-wider">Wardrobe Items</div>
                </div>
                <div>
                  <div className="text-4xl font-serif font-light text-foreground mb-2">12</div>
                  <div className="text-sm text-muted-foreground uppercase tracking-wider">Saved Outfits</div>
                </div>
                <div>
                  <div className="text-4xl font-serif font-light text-foreground mb-2">87</div>
                  <div className="text-sm text-muted-foreground uppercase tracking-wider">Days Tracked</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
